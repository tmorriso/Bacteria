/**
 * @author E.S.Boese
 * @edited by Thomas Morrison
 * @version Fall 2014
 * Project #2
 */

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include "User.h"
#include "Book.h"
#include "Library.h"
using namespace std;


Library::Library(string bookFilename, string userFilename)
{
	readInBookList(bookFilename);
	readUserFile(userFilename);
}

void Library::printUsers()
{
	for (int i=0; i<userList.size(); i++)
	{
		cout << userList.at(i).toString() << endl;
	}
}


void Library::readInBookList(string filename)
{
	ifstream infile;
	infile.open(filename.c_str());
	string line;
	int count = 0;
	
	if (infile.is_open())
	{
		cout << "Reading in book list from file: " << filename << endl;
		while ( getline (infile, line) )
		{
			int comma_pos = line.find(",");
					
			string author = line.substr(0, comma_pos);
			string title = line.substr(comma_pos+1); 			

			// TODO: create new Book object
			Book book(author, title);
			
			// TODO: add Book object to vector
			bookList.push_back(book);
			
			count++;
		}
		cout << count << " books read in. Closing book list file." << endl;
		infile.close();
	}
}

void Library::readUserFile(string filename)
{
	ifstream infile;
	infile.open(filename.c_str());
	
	if (infile.is_open())
	{
		cout << "Reading in user list from file: " << filename << endl;
		int count = 0;
		while (infile)
		{
			string author, ratings;
			getline(infile, author);
			
			if (author != "")
			{
				getline(infile, ratings);
				
				// TODO: Create new User object
				User newuser(author, ratings);
				
				// TODO: Add new User object to vector
				userList.push_back(newuser);
				
				count++;
			}
		}
		cout << count << " users read in. Closing user file." << endl;
		infile.close();
	}
}

void Library::printBooks()
{
	for (int i=0; i<bookList.size(); i++)
	{
		Book book = bookList.at(i);
		cout << book.toString() << endl;
	}
}

/**
 * Return the current user
 * @param file
 * @return User object with this User
 */
User Library::getCurrentUser(string filename)
{
	ifstream infile;
	infile.open(filename.c_str());
	User currentUse;
	if (infile.is_open())
	{
		while (infile)
		{
			string author, ratings;
			getline(infile, author);
			
			if (author != "")
			{
				getline(infile, ratings);
				
				// TODO: Create new User object
				User currentUse(author, ratings);
				return currentUse;
			}
			
		}
		infile.close();
	}
	
}

/**
 * Return the most similar user
 * @param currentUser the user we want to find a similar user for
 * @return
 */
User Library::getMostSimilarUser(User currentUser)
{
	double bestSimilarity = 0;
	double similarity = 0;
	User bestUser; // Keep track of the user with the highest score
	User userCompare; // The user to compare to current user
	for (int i = 0; i < userList.size(); i++)
	{
		userCompare = userList[i];
		if (currentUser.getId() != userCompare.getId())
		{
			similarity = currentUser.getSimilarity(userCompare);
			if (similarity > bestSimilarity)
			{
				bestUser = userCompare;
				bestSimilarity = similarity;
			}
		}
	}
	return bestUser;
}

/**
 * Print out the books rated by the user with a 3 or 5 rating that the
 * current user has not read yet
 * @param mostSimilarUser user with the most similarly rated books to current user
 * @param currentUser the current Uuser we are making recommendations for 
 * */
 void Library::printRecommendations(User mostSimilarUser, User currentUser)
 {
	 cout << "We recommend for you the following books:" << endl;
	 // your code here
	 for (int i = 0; i < bookList.size(); i++)
	 {
		 Book currentBook = bookList[i];
		 if (mostSimilarUser.getRatingAt(i) == 3 || mostSimilarUser.getRatingAt(i) == 5)
		 {
			 if (currentUser.getRatingAt(i) == 0)
			 {
				 cout << currentBook.toString() << endl;
			 }
		 }
	 }
 }

