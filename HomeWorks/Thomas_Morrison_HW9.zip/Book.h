//Book header file
#ifndef BOOK_H
#define BOOK_H
class Book
{
	// Instance variables 
	private:
		std::string author; 
		std::string title;
	// Functions
	public:
		Book();
		Book(std::string, std::string);
		std::string getAuthor();
		std::string getTitle();
		void setAuthor(std::string);
		void setTitle(std::string);
		std::string toString();
};
#endif
	
