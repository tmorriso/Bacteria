// Book.cpp 
// Thomas Morrison
// November 11, 2015
// HW 8 Part 1 and HW 9
//--------------------------------------
// Purpose: Book Class to keep track of 
//             books titles and authors
//---------------------------------------

#include <iostream>
#include <string>
#include "Book.h" 
using namespace std;

Book::Book()
{
	author = "Unknown";
	title = "Unknown";
}
Book::Book(string au, string tl)
{
	author = au;
	title = tl;
}
string Book::getAuthor()
{
	return author;
}
string Book::getTitle()
{
	return title; 
}
void Book::setAuthor(string au)
{
	author = au;
}
void Book::setTitle(string tl)
{
	title = tl;
}
string Book::toString()
{
	return title + " by " + author;
}
