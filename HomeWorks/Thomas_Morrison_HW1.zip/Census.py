# Thomas Morrison
# August 28, 2015
# Assignment #1 Part 1
# US Population Census Problem

cp = 318892103 # current population
dy = 365       # days in a year
hd = 24	       # hours in a day
mh = 60        # minutes in an hour
sm = 60        # seconds in a minute

sy = dy*hd*mh*sm  # seconds in a year

br = sy//8      # Total births for one year
dr = sy//13     # Total deaths for one year
ir = sy//40     # Total number of new immigrants in one year

np = cp+br+ir-dr  # New population in one year

print ("The population will be", np)

# The code first determines the number of seconds in a year by using the relevant conversion factors. Using this number it determines the number of births, deaths, and immigrants in one year, keeping in mind that the numbers can't be decimals. It then finds the new population (np) by adding the births and immigrants and subtracting the deaths to the current population (cp). Finally the caode prints a statement with the result.


