# Lab 1: Practice running a program and uploading to Moodle
# Author E.S.Boese
# Version Fall 2015
a = 5;
b = 3;
print("Tom", a*b)
